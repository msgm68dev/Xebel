#Source: https://www.geeksforgeeks.org/find-paths-given-source-destination/

# Python program to print all paths from a source to destination. 

from collections import defaultdict 
import time #For measuring codes execution time
import copy #for full clone of a list
from collections import Counter #For counting distinct values in list
import sys, os #for seeing Error line no.
try:
    import cPickle as pickle
except ModuleNotFoundError:
    import pickle


geant = r"E:\Mostafa\PHD\THESIS\TEZ\data\geant\vtx 0-22\geant(i,j)+(j,i).txt"
mytopo1 = r"E:\Mostafa\PHD\THESIS\TEZ\data\mytopo1\mytopo1(i,j)&(j,i).txt"

##########################
#######				 #####
Dataset = geant
allowed_common_edges_percent = 80
allowed_path_stretch_factor = 100.0
#######				 #####
##########################

class ijPaths:
	src = -1
	dst = -1
	def __init__(self, paths, epaths = None):
		if paths:
			self.Paths = sorted(paths, key=len)
			self.VLengths = [len(path) for path in paths]
			self.PathsNo = len(paths)
			if self.VLengths[0] > 0:
				self.src = paths[0][0]
				self.dst = paths[0][-1]
			else:
				raise Exception('First path\'s length is zero')
			if not epaths:
				self.EPaths = self._paths_to_epaths(paths)
			else:
				self.EPaths = epaths
			self.ELengths = [len(epath) for epath in self.EPaths]
		else:
			raise Exception('Error: NULL path')
			
	def _path_to_epath(self, path, ndigit = 0):
		if ndigit < 1:
			return [ str(path[i]) + '-' + str(path[i+1]) for i in range(len(path)-1)] 
		else:
			return [ str(path[i]).zfill(ndigit) + '-' + str(path[i+1]).zfill(ndigit) for i in range(len(path)-1)] 
	def _paths_to_epaths(self, paths, ndigit = 0):
		return [self._path_to_epath(path, ndigit) for path in paths]

	def _epath_similarity(self, ep1, ep2):
		shorter = ep1
		longer = ep2
		if len(ep1) > len(ep2):
			shorter = ep2
			longer = ep1
		counter = 0
		for edge in shorter:
			if edge in longer:
				counter = counter + 1
		return counter / len(shorter)
	def _have_similar_epath_in_list(self, epath, epaths, acep):
			for ep in epaths:
				if self._epath_similarity(ep, epath) > acep:
					return True
			return False
	def prone(self, acep, aps):
		if acep <= 0 or aps <= 0:
			raise Exception('Acep & Aps are not set!')
		shortest_len = len(self.EPaths[0])
		pronned_paths = []
		pronned_epaths = []
		for i in range(self.PathsNo):
			ep = self.EPaths[i]
			if not self._have_similar_epath_in_list(ep, pronned_epaths, acep):
				if len(ep) <= aps * shortest_len:
					pronned_epaths.append(ep)
					pronned_paths.append(self.Paths[i])
		return ijPaths(pronned_paths, pronned_epaths)

	def print_stats(self, acep, aps):
		if self.VLengths == 0:
			print('No path exist!')
			return
		elif self.ELengths == 0:
			print('Just 1 path exist from', self.src, 'to', self.dst)
			return
		elif '-' not in self.EPaths[0][0]:
			raise Exception ('Epaths[0][0] is an Invalid path')
		lens_sum = dict(Counter(self.ELengths))
		print(" %d>%d ::  ce %.2f  ps %d \n# of paths: %d" % ( self.src , self.dst , round(acep, 2), aps, self.PathsNo))
		print('\t', lens_sum)
		print('.\n')


DefaultParams = '100:999'
#This class represents a directed graph 
# using adjacency list representation 
class Graph: 
	# self.allPaths = [ [ [] for i in range(self.V) ] for i in range(self.V) ]
	# self.allpLengs = copy.deepcopy(self.allPaths)
	# self.paramdict = {'99-99.0': [ [ None for i in range(self.V) ] for i in range(self.V) ] }

	'''
	The main data of all paths, that is :
	*   A dictionary with:
		+	Key: string of format: 'acep%:aps*', e.g. '80:3.5' 
		+	Value: list of lists (V * V list) of pronned paths from a source to a destination
		+	Example:	The value of _PATHs['80:3.5'][i][j] means: 
						List of paths from i to j regarding acep=80% and aps=3.5x
				The content is:
				$	an ijPaths instance with src=i, dst=j, acep=80, aps=3.5
				$	None (default): if we do not calculate paths i to 
					j with '80-3.5' but this key exist
	'''
	_PATHs = {}
	def __init__(self,dataset): 
		with open(dataset) as f:
			array = [[int(x) for x in line.split()] for line in f]

		self._file = dataset
		self.file = dataset.split('/')[-1].split('\\')[-1]
		self.topology = self.topology.split('.')[0]
		self.directory = os.path.dirname(dataset)

		# default dictionary to store graph 
		self.graph = defaultdict(list) 
		
		#No. of vertices 
		self.V= max(max(array)) + 1

		nEdge = 0
		for e in array:
			self._addEdge(e[0], e[1])
			nEdge = nEdge + 1
		
		#No. of Edges
		self.E = nEdge

		self._PATHs[DefaultParams] = [ [ None for i in range(self.V) ] for i in range(self.V) ]
	
    

    @property
	def directory(self):
        return os.path.dirname(self._file)

    @property
	def topology(self):
        return  self._file.split('/')[-1].split('\\')[-1].split('.')[0]
    
	@property
	def pkl(self):
        return os.path.join(self.directory, self.topology) + '.pkl'
    

    # @x.setter
    # def x(self, x):
    #     if x < 0:
    #         self.__x = 0
    #     elif x > 1000:
    #         self.__x = 1000
    #     else:
    #         self.__x = x
		
	# function to add an edge to graph 
	def _addEdge(self,u,v): 
		self.graph[u].append(v) 

	'''A recursive Depth First Search function to print all paths from 'u' to 'd'. 
	visited[] keeps track of vertices in current path. 
	path[] stores actual vertices and path_index is current 
	index in path[]'''
	def _calc_paths_dfs(self, u, d, visited, path, paths): 

		# Mark the current node as visited and store in path 
		visited[u]= True
		path.append(u) 

		# If current vertex is same as destination, then print 
		# current path[] 
		if u ==d: 
			paths.append(path.copy())
		else: 
			# If current vertex is not destination 
			#Recur for all the vertices adjacent to this vertex 
			for i in self.graph[u]: 
				if visited[i]==False: 
					self._calc_paths_dfs(i, d, visited, path, paths) 
					
		# Remove current vertex from path[] and mark it as unvisited 
		path.pop() 
		visited[u]= False

	# Returns all paths from 's' to 'd' sorted by path length
	def _calc_paths_list(self,s, d): 

		# Mark all the vertices as not visited 
		visited =[False]*(self.V) 

		# Create an array to store paths 
		path = [] 

		# Create empty list of paths from s to d
		paths = []
		
		# Call the recursive helper function to print all paths 
		self._calc_paths_dfs(s, d,visited, path, paths)

		paths.sort(key=len) #Sort list of lists by length of sublists

		# path_lengths = [len(p) for p in paths]
		return paths

	def _param_to_str(self, acep, aps):
		return str(acep) + '-' + str(aps)

	def getPaths(self, src, dst, acep, aps):
		pstr = self._param_to_str(acep, aps)
		if not pstr in self._PATHs.keys():
			self._PATHs[pstr] = [ [ None for i in range(self.V) ] for i in range(self.V) ]
		if not self._PATHs[pstr][src][dst]:
			# Path search dfs function:
			paths = self._calc_paths_list(src, dst)
			ijpaths = ijPaths(paths)
			self._PATHs[DefaultParams][src][dst] = ijpaths
			# Pronong function:
			p_ijpaths = ijpaths.prone(acep, aps)
			self._PATHs[pstr][src][dst] = p_ijpaths

		self._PATHs[pstr][src][dst].print_stats(acep, aps)
		return self._PATHs[pstr][src][dst]

	def save(self):
		with open(self.pkl, 'wb') as output:
			pickle.dump(self, output, pickle.HIGHEST_PROTOCOL)

	def load
		
def main():
	# Create a graph given in the above diagram 
	acep = 100
	aps = 100
	
	g = Graph(Dataset)
	flag = True
	cmd = 1
	while flag:
		try:
			print('1. Calc SINGLE src/dst paths')
			print('2. Calc ALL pairs\' paths')
			cmd = int(input('choose an option: '))
			if cmd < 1 or cmd > 2:
				raise Exception('Invalid command')
		except:
			print ('Bad command!')
		if cmd == 1:
			try:
				i = int(input("Enter i: "))
				j = int(input("Enter j: "))
				if i < 0 or j < 0 or i >= g.V or j >= g.V:
					raise 
				acep = int(input("Common Edge  %: ") or allowed_common_edges_percent) / 100
				aps = float(input("Path Stretch *: ") or allowed_path_stretch_factor)
			except:
				print ('Bad input!')
				continue
			#1. Paths calculation  *****************************************
				#epaths : Edge -stated- Paths
				#epaths_sp : Edge Paths _ Sorted by length and Pronned by acep, aps
			g.getPaths(i, j, acep, aps)
			#\						*****************************************

		elif cmd == 2:
			acep = int(input("Common Edge  %: ") or allowed_common_edges_percent) / 100
			aps = float(input("Path Stretch *: ") or allowed_path_stretch_factor)

			# Execution
			start_time = time.time()
			PL = 0
			for s in range(0, g.V):
				for d in range(0, g.V):
					g.getPaths(s, d, acep, aps)
			print("+++ (%s seconds) (N= %d CE= %d PS= %.2f) Average: %.2f" % (round((time.time() - start_time),2), g.V, acep, aps, PL/(g.V * (g.V-1))) )
			input("Press Enter key to exit ...")


		# Ask for Exit
		if input("press y to exit: ").lower() == 'y':
			flag = False

# main()
print('Dataset = geant or mytopo1')
print('acep = 0.0 .. 1.0 --> (0.0 gives disjoint paths)')
print('aps = 1.0 .. 100  --> 1 gives just shortest paths')
print('g = Graph(Dataset)')
print('g.getPaths(src, dst, acep, aps) like g.getPaths(11,12,0.8,3.5)')