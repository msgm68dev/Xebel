#Source: https://www.geeksforgeeks.org/find-paths-given-source-destination/

# Python program to print all paths from a source to destination. 

from collections import defaultdict 
import time
import copy 
from collections import Counter #For counting distinct values in list
import sys, os

geant = r"E:\Mostafa\PHD\THESIS\TEZ\data\geant\vtx 0-22\geant(i,j)+(j,i).txt"
mytopo1 = r"E:\Mostafa\PHD\THESIS\TEZ\data\mytopo1\mytopo1(i,j)&(j,i).txt"

##########################
#######				 #####
Dataset = geant  
#######				 #####
##########################


#This class represents a directed graph 
# using adjacency list representation 
class Graph: 

	def __init__(self,dataset): 
		with open(Dataset) as f:
			array = [[int(x) for x in line.split()] for line in f]

		vertices = max(max(array)) +1
		
		#No. of vertices 
		self.V= vertices

		# default dictionary to store graph 
		self.graph = defaultdict(list) 

		for e in array:
			self.addEdge(e[0], e[1])

	# function to add an edge to graph 
	def addEdge(self,u,v): 
		self.graph[u].append(v) 

	'''A recursive function to print all paths from 'u' to 'd'. 
	visited[] keeps track of vertices in current path. 
	path[] stores actual vertices and path_index is current 
	index in path[]'''
	def getAllPathsUtil(self, u, d, visited, path, paths): 

		# Mark the current node as visited and store in path 
		visited[u]= True
		path.append(u) 

		# If current vertex is same as destination, then print 
		# current path[] 
		if u ==d: 
			paths.append(path.copy())
		else: 
			# If current vertex is not destination 
			#Recur for all the vertices adjacent to this vertex 
			for i in self.graph[u]: 
				if visited[i]==False: 
					self.getAllPathsUtil(i, d, visited, path, paths) 
					
		# Remove current vertex from path[] and mark it as unvisited 
		path.pop() 
		visited[u]= False

	# Prints all paths from 's' to 'd' 
	def getAllPaths(self,s, d): 

		# Mark all the vertices as not visited 
		visited =[False]*(self.V) 

		# Create an array to store paths 
		path = [] 

		# Create empty list of paths from s to d
		paths = []
		
		# Call the recursive helper function to print all paths 
		self.getAllPathsUtil(s, d,visited, path, paths)

		paths.sort(key=len) #Sort list of lists by length of sublists

		path_lengths = [len(p) for p in paths]
		return path_lengths, paths

class Path:
	
		
def main():
	# Create a graph given in the above diagram 
	g = Graph(Dataset)

	#all_paths 
	# Paths = [ [[]]*g.V for i in range(g.V) ]
	Paths = [ [ [] for i in range(g.V) ] for i in range(g.V) ]

	PLengs = copy.deepcopy(Paths)
	PCount = copy.deepcopy(Paths)


	# def CalculatePaths():
	# 	for s in range(0, g.V):
	# 		for d in range(0, g.V):
	# 			lens, paths = g.getAllPaths(s, d)
	# 			Paths[s][d] = paths
	# 			PLengs[s][d] = lens
	# 			PCount[s][d] = len(lens)
		
		
	#Execution
	# start_time = time.time()
	# CalculatePaths()
	# print("+++ All paths calculated in %s seconds " % round((time.time() - start_time),2))

	flag = True
	while flag:
		try:
			i = int(input("Enter i: "))
			j = int(input("Enter j: "))

			#1. Paths calculation  *****************************************
			# print('1. Calculate again')
			lens, paths = g.getAllPaths(i, j)
			lens_val = list(Counter(lens).keys()) # OR: list(set(lens))
			lens_cnt = list(Counter(lens).values())
			Lens={}
			for i in range(len(lens_val)):
				Lens[lens_val[i]] = lens_cnt[i]
			#\						*****************************************

			print('%d paths of lengths: ' %len(lens), Lens)
			c=1
			for p in paths:
				if c < 10:
					print(c, p)
					c=c+1
				else:
					print("... %d more " % (len(paths)-c))
					break
			
			#2. Fetch from calculated paths
			# print('______________________________')
			# print('2. Fetch from calculated paths')
			# lens2 = PLengs[i][j]
			# paths2 = Paths[i][j]
			# print('%d paths2 of lengths2: ' %len(lens2), lens2)
			# c=1
			# for p in paths2:
			# 	if c < 10:
			# 		print(c, p)
			# 		c=c+1
			# 	else:
			# 		print("... ({}} more)", len(paths2)-c)
			# 		break

		except Exception as e:
			exc_type, exc_obj, exc_tb = sys.exc_info()
			# fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
			# print(exc_type, fname, exc_tb.tb_lineno)
			print('Something went wrong!: ' , str(e), "Line: ", exc_tb.tb_lineno)

		if input("press y to exit: ").lower() == 'y':
			flag = False

	#lens, paths = g.getAllPaths(s, d)


main()