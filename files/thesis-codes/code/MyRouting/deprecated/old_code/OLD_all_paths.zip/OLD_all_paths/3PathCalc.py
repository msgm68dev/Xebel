#Source: https://www.geeksforgeeks.org/find-paths-given-source-destination/

# Python program to print all paths from a source to destination. 

from collections import defaultdict 
import time
import copy 
from collections import Counter #For counting distinct values in list
import sys, os

geant = r"E:\Mostafa\PHD\THESIS\TEZ\data\geant\vtx 0-22\geant(i,j)+(j,i).txt"
mytopo1 = r"E:\Mostafa\PHD\THESIS\TEZ\data\mytopo1\mytopo1(i,j)&(j,i).txt"

##########################
#######				 #####
Dataset = geant
allowed_common_edges_percent = 80
allowed_path_stretch_factor = 100.0
#######				 #####
##########################


#This class represents a directed graph 
# using adjacency list representation 
class Graph: 

	def __init__(self,dataset): 
		with open(Dataset) as f:
			array = [[int(x) for x in line.split()] for line in f]

		# default dictionary to store graph 
		self.graph = defaultdict(list) 
		
		#No. of vertices 
		self.V= max(max(array)) +1

		nEdge = 0
		for e in array:
			self.addEdge(e[0], e[1])
			nEdge = nEdge + 1
		self.E = nEdge
		
	# function to add an edge to graph 
	def addEdge(self,u,v): 
		self.graph[u].append(v) 

	'''A recursive function to print all paths from 'u' to 'd'. 
	visited[] keeps track of vertices in current path. 
	path[] stores actual vertices and path_index is current 
	index in path[]'''
	def getAllPathsUtil(self, u, d, visited, path, paths): 

		# Mark the current node as visited and store in path 
		visited[u]= True
		path.append(u) 

		# If current vertex is same as destination, then print 
		# current path[] 
		if u ==d: 
			paths.append(path.copy())
		else: 
			# If current vertex is not destination 
			#Recur for all the vertices adjacent to this vertex 
			for i in self.graph[u]: 
				if visited[i]==False: 
					self.getAllPathsUtil(i, d, visited, path, paths) 
					
		# Remove current vertex from path[] and mark it as unvisited 
		path.pop() 
		visited[u]= False

	# Prints all paths from 's' to 'd' 
	def getAllPaths(self,s, d): 

		# Mark all the vertices as not visited 
		visited =[False]*(self.V) 

		# Create an array to store paths 
		path = [] 

		# Create empty list of paths from s to d
		paths = []
		
		# Call the recursive helper function to print all paths 
		self.getAllPathsUtil(s, d,visited, path, paths)

		paths.sort(key=len) #Sort list of lists by length of sublists

		path_lengths = [len(p) for p in paths]
		return path_lengths, paths

def to_epath(path, ndigit):
		return [ str(path[i]).zfill(ndigit) + '-' + str(path[i+1]).zfill(ndigit) for i in range(len(path)-1)] 
	
def to_epaths(paths, ndigit):
	return [ to_epath(path, ndigit) for path in paths] 
	
def epath_sim(ep1, ep2):
		shorter = ep1
		longer = ep2
		if len(ep1) > len(ep2):
			shorter = ep2
			longer = ep1
		counter = 0
		for edge in shorter:
			if edge in longer:
				counter = counter + 1
		return counter / len(shorter)
	
def have_similar(epath, epaths, acep):
		for ep in epaths:
			if epath_sim(ep, epath) > acep:
				return True
		return False

def prone_epaths(epaths, acep=1.0, aps=100):
	epaths_s = sorted(epaths, key=len)
	shortest_len = len(epaths[0])
	pronned = []
	for ep in epaths_s:
		if not have_similar(ep, pronned, acep):
			if len(ep) <= aps * shortest_len:
				pronned.append(ep)
	return pronned
	
def print_epaths_stat(epaths, acep, aps):
	# print('-----------------------')
	if len(epaths) == 0:
		print(' No path exist!')
		return
	elif len(epaths[0]) == 0:
		return
	elif '-' not in epaths[0][0]:
		return
	src = int(epaths[0][0].split('-')[0])
	dst = int(epaths[0][-1].split('-')[-1])
	lens = [len(epath) for epath in epaths]
	lens_sum = dict(Counter(lens))
	print("%d>%d ::  ce %.2f  ps %d \n# of paths: %d" % (src , dst , round(acep, 2), aps, len(lens)))
	print(lens_sum)
	print('-----------------------\n')

def main():
	# Create a graph given in the above diagram 
	acep = 100
	aps = 100
	
	g = Graph(Dataset)
	flag = True
	cmd = 1
	while flag:
		try:
			cmd = int(input("1. Calc SINGLE src/dst paths\n2. Calc ALL pairs' paths"))
			if cmd < 1 or cmd > 2:
				raise
		except:
			print ('Bad command!')
		if cmd == 1:
			try:
				i = int(input("Enter i: "))
				j = int(input("Enter j: "))
				if i < 0 or j < 0 or i >= g.V or j >= g.V:
					raise 
				acep = int(input("Common Edge  %: ") or allowed_common_edges_percent) / 100
				aps = float(input("Path Stretch *: ") or allowed_path_stretch_factor)
			except:
				print ('Bad input!')
				continue
			#1. Paths calculation  *****************************************
				#epaths : Edge -stated- Paths
				#epaths_sp : Edge Paths _ Sorted by length and Pronned by acep, aps
			lens, paths = g.getAllPaths(i, j)
			epaths = to_epaths(paths, len(str(g.V-1)))
			epaths_sp = prone_epaths(epaths, acep, aps)
			#\						*****************************************

			print_epaths_stat(epaths_sp, acep, aps)

		elif cmd == 2:
			acep = int(input("Common Edge  %: ") or allowed_common_edges_percent) / 100
			aps = float(input("Path Stretch *: ") or allowed_path_stretch_factor)

			# Execution
			start_time = time.time()
			PL = 0
			for s in range(0, g.V):
				for d in range(0, g.V):
					if d == s:
						continue
					lens, paths = g.getAllPaths(s, d)
					epaths = to_epaths(paths, len(str(g.V-1)))
					epaths_sp = prone_epaths(epaths, acep, aps)
					pl = len(epaths_sp)
					print(' %d -> %d : %d paths' % (s, d, pl))
					PL = PL + pl
			print("+++ (%s seconds) (N= %d CE= %d PS= %.2f) Average: %.2f" % (round((time.time() - start_time),2), g.V, acep, aps, PL/(g.V * (g.V-1))) )
			input("Press Enter key to exit ...")


		# Ask for Exit
		if input("press y to exit: ").lower() == 'y':
			flag = False

main()